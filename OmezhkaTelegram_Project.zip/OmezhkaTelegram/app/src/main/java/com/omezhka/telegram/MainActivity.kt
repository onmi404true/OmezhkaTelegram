package com.omezhka.telegram

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val pink = Color.rgb(255, 226, 241)
    private val dark = Color.rgb(85, 48, 76)
    private val accent = Color.rgb(232, 137, 184)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 28, 22, 22)
        setBackgroundColor(pink)
    }

    private fun text(value: String, size: Float, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(dark)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 8, 4, 8)
        }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(accent)
        setOnClickListener { action() }
    }

    private fun showHome() {
        val root = base()
        root.addView(text("♡ Omezhka Telegram ୨୧", 26f, true))
        root.addView(text("Твой милый уголок для переписок", 15f))
        root.addView(button("♡ Открыть чаты", ::showChats))
        root.addView(button("୨୧ Омежный редактор", ::showEditor))
        root.addView(text("Демонстрационная версия интерфейса. Подключение к Telegram ещё не настроено.", 13f))
        setContentView(root)
    }

    private fun showChats() {
        val root = base()
        root.addView(text("♡ Мои чаты", 25f, true))
        root.addView(text("Здесь появится список переписок после подключения официального Telegram API.", 16f))
        root.addView(text("Пока это макет — реальные сообщения не загружаются.", 14f))
        root.addView(button("Назад", ::showHome))
        setContentView(root)
    }

    private fun showEditor() {
        val root = base()
        root.addView(text("୨୧ Омежный редактор", 24f, true))
        val input = EditText(this).apply {
            hint = "Напиши сообщение..."
            minLines = 3
            setTextColor(dark)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
        }
        root.addView(input)
        val output = text("Тут появится результат ♡", 17f)
        root.addView(button("Сделать омежным ♡") {
            val original = input.text.toString().trim()
            if (original.isBlank()) {
                output.text = "Сначала напиши сообщение ♡"
            } else {
                var result = original
                result = result.replace(Regex("\\bнет\\b", RegexOption.IGNORE_CASE)) { "н-нет" }
                result = result.replace(Regex("\\bпривет\\b", RegexOption.IGNORE_CASE)) { "п-привет" }
                result = result.replace(Regex("\\bбоюсь\\b", RegexOption.IGNORE_CASE)) { "б-боюсь" }
                output.text = "$result … ♡"
            }
        })
        root.addView(output)
        root.addView(button("Скопировать") {
            val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clip.setPrimaryClip(android.content.ClipData.newPlainText("Omezhka", output.text))
            Toast.makeText(this, "Скопировано ♡", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Назад", ::showHome))
        setContentView(root)
    }
}
